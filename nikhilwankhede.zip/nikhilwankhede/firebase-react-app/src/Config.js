export const firebaseConfig = {
    apiKey: "AIzaSyBfLGd8FZ3_OY6iYeN4NalNH6WOLsWwNaM",
    authDomain: "fir-react-963cc.firebaseapp.com",
    databaseURL: "https://fir-react-963cc.firebaseio.com",
    projectId: "fir-react-963cc",
    storageBucket: "fir-react-963cc.appspot.com",
    messagingSenderId: "314722927516",
    appId: "1:314722927516:web:9cda9b7abe6ba25768be59",
    measurementId: "G-NEQFH2MQ98"
  };