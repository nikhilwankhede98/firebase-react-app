import React from 'react';
import logo from './logo.svg';
import './App.css';

//Firebase Database and Configuration
import firebase from 'firebase';
import {firebaseConfig} from './Config.js';

//Initialize Firebase
firebase.initializeApp(firebaseConfig);



class App extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {
      userarr: [],
      accarr: []
    
    };
  };

  componentDidMount() {
    const userRef = firebase.database().ref('users');
    const accountRef = firebase.database().ref('accounts');

    accountRef.on('value',(snapshot) => {
      let accounts = snapshot.val();
      let newState1 = [];

      for (let account in accounts) {
        newState1.push({
          id:account,
          apptitles: accounts[account].apps.title
        });
      }

      this.setState({
        accarr:newState1
      });
    });

    userRef.on('value',(snapshot) => {
      let users = snapshot.val();
      let newState = [];
      
      for (let user in users) {
        newState.push({
          id:user,
          acc_id: users[user].account,
          name: users[user].name
        });
      
      }
      this.setState({
        userarr: newState
      });
    });
  };


  render() {
    
    return (
     
      <div>
        
        <nav class="navbar fixed-top navbar-dark bg-dark">
          <h1 className="text">Welcome To React-Firebase App</h1>
        </nav>        
        <br />1
          <section id="usersctn">
            <div>
              <br />
              <br />
              <img src={logo} className="App-logo" alt="logo" />
              <br />
              <div class="card border-primary"  className="card">
                <div className="output">
                  <h1 class="card-title font-italic font-weight-bold text-dark ">RESULT</h1>
                  <br />
                  {this.state.userarr.map((user) => {
                    
                    return (
                      <div>
                        <div>
                          <div class="card-text">
                              <h3 id="accid">acc_id : {user.acc_id}</h3>
                              <h3 id="name">name : {user.name}</h3>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
              
            </div>
          </section> 
          <br />
          <div className="rating-form">
            <form className="form">
              <input className="input" type = "text" id="inputText" placeholder = "Rate Our App Out Of 5" />
              <br />
              <button type="button"  className="btn btn-primary btn-lg " >Submit Rating</button>
              </form>
          </div>
          <br />
          <div class="jumbotron">
            <h1 class="display-4">Hello, world!</h1>
            <p class="lead srong">This is a simple Application based on React and Firebase</p>
            <p class="lead font-italic font-weight-bold text-dark"> KEEP LEARNING : )</p> 
          </div>
      </div>
    );
  };
}



export default App;
